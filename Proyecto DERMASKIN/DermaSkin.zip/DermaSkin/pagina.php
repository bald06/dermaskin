<?php
include('config\conexion.php');
//session_start();
if(isset($_SESSION['logindat']) || isset($_POST['envio']))

{
	if(isset($_POST['envio']))
	{
		$email=$_POST['email'];
		$pass=$_POST['password'];
		$resultado = $con->query("select * from cliente where Email='$email' and Password='$pass'");
		if(mysqli_num_rows($resultado)>0)
			{
				$fila = mysqli_fetch_array($resultado);
				$_SESSION['logindat']=$fila;
				if($fila[7]=='1')
				{
					//die(var_dump($fila));
					header('location: sistema/index.php');
				}
				else if($fila[7]=='2')
				{
						header('location: mostrar.php');
				}else
				{
					header('location: registro.php');
				}
			}
    }
	else
	{
		if(isset($_SESSION['logindat']))
			{	
				echo "hola sesion";
				if($_SESSION['logindat'][7]=="1")
				{
					header('location: sistema/index.php');
					
				}
				else
				{
					if($_SESSION['logindat'][7]=="2")
					{
						header('location: mostrar.php');
					}
				}
			}
	}
}
else
{
	header('location: registro.php');
}
?>