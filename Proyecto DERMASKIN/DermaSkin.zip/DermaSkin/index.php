<?php
include_once "pedido.php"; 
require_once "templates/header.php";
require_once "templates/links.php";
?>
<style>
    #cajaNormal {
    width: 90%;
    border: 3px;
    margin: 60px 70px;
    }
</style>

<?php
    $limite=12;
    $totalQuery = $con->query('SELECT COUNT(*) FROM producto') or die($con->error);
    $totalProductos = mysqli_fetch_row($totalQuery);
    $totalBotones = round($totalProductos[0]/$limite);
    //die($totalBotones);
    if (isset($_GET['pagina'])) {
        $pagina = $_GET['pagina'];
        $query = mysqli_query($con,"SELECT * FROM producto  where Stock > 0  LIMIT ". (($pagina-1)*10).",$limite") or die($con->error);
                
    }else{
        $query = mysqli_query($con,"SELECT u.*,p.* FROM producto u INNER JOIN categoria p ON u.id_categoria = p.id_categoria WHERE Stock > 0 LIMIT 0,12 ");
    }
        
                
    
?>

<table id="clientes">
        <thead>
<div id="cajaNormal">
<?php if($mensaje!=""){ ?>
    <div class="alert alert-success" >
       <?php echo $mensaje; ?> 
        <a href="mostrar.php" class="badge badage-">Ver Carrito</a>
    </div><br><br>
<?php } ?>
        <div class="row">
            <?php
                if ($query) {
                    while ($data = mysqli_fetch_array($query)) { 
                        
            ?>
            <div class="col-3">
                <div class="card">
                    <img 
                        class="card-img-top" 
                        src="assets/img/<?php echo $data['Imagen_Producto'];?>" 
                        alt="<?php echo $data['Imagen_Producto'];?>"  
                        title="<?php echo $data['Nombre_Producto'];?>"
                        data-toggle="popover"
                        data-trigger="hover"
                        data-content="<?php echo $data['Descripcion_Producto'];?>"
                        height="317px"
                        
                    >

                <div class="card-body" >
                        <span><?php echo $data['Nombre_Producto'];?></span>
                        <h5 class="card-title">$<?php echo $data['Precio'];?></h5>
                    <form method="post" action="">
                        <input type="hidden" name="id" id="id" value="<?php echo ($data['id_producto']);?>">
                        <input type="hidden" name="nombre" id="nombre" value="<?php echo ($data['Nombre_Producto']);?>">
                        <input type="hidden" name="precio" id="precio" value="<?php echo ($data['Precio']);?>">
                        <input type="hidden" name="cantidad" id="cantidad" value="<?php echo 1;?>">
                    <!--inicio boton modal-->
                    <button class="btn btn-outline-primary btnProducto"
                    value="<?php ($data['id_producto']);?>" 
                            data-toggle="modal"
                            data-target="#modal1"
                            idProducto=<?= $data['id_producto'] ?> 
                            type="button">Ver detalles
                    </button> <!--cierre boton modal-->
                    <button class="btn btn-primary" 
                            name="btnAccion" 
                            value="Agregar" 
                            type="submit">Agregar al carrito
                        </button>
                    </form>
                    </form>
                  </div>
                  </div>
                </div>   
                  <?php 
                   }
                  } ?>
            </div>
                        <!--inicio modal-->
                        <div class="modal fade" id="modal1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content" id="productoRes">
                                
                                </div>
                            </div>
                        </div> 
                </div>     
        <br>
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <?php 
                    if(isset($_GET['pagina'])){
                        if($_GET['pagina']>1){
                           echo '<li class="page-item"><a class="page-link" href="index.php?pagina='.($_GET['pagina']>0 ? ($_GET['pagina']-1):1).'"><<</a></li>';
                        }
                    }
                ?>
                    <?php 
                        for($k=0;$k<=$totalBotones;$k++){
                            echo '<li><a class="page-link" href="index.php?pagina='.($k+1).'">'.($k+1).'</a></li>';
                        }
                        if(isset($_GET['pagina'])){
                            if ($_GET['pagina'] < $totalBotones+1) {
                            echo '<li class="page-item"><a class="page-link" href="index.php?pagina='.($_GET['pagina']+1).'">></a></li>';
                            echo '<li class="page-item"><a class="page-link" href="index.php?pagina='.($totalBotones+1).'">>></a></li>';

                        }else{
                           
                        }
                    }
                    ?> 
                
            </ul>
        </nav>
<?php 
require_once "templates/footer.php";
?>
