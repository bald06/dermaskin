<?php 
	$server = 'localhost:3308';
	$user = 'root';
	$password = '';
	$db = 'derma_skin';

	$con = mysqli_connect($server,$user,$password,$db) or die("No se ha realizado la conexion a la base de datos");
	mysqli_query($con, "SET NAMES 'utf8'");

	if(!$con){
		echo "No se ha realizado la conexion a la base de datos";
	}
	session_start();
?>