-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3308
-- Tiempo de generación: 30-07-2020 a las 08:51:59
-- Versión del servidor: 8.0.18
-- Versión de PHP: 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `derma_skin`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE IF NOT EXISTS `categoria` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre_categoria` varchar(50) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `Nombre_categoria`) VALUES
(1, 'Piel'),
(2, 'Mujer'),
(3, 'Cuerpo'),
(4, 'Hombres'),
(5, 'Cabello');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre_Cliente` varchar(100) NOT NULL,
  `Apellidos_Cliente` varchar(100) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `idRol` int(11) NOT NULL,
  PRIMARY KEY (`id_cliente`),
  KEY `pk_idrol` (`idRol`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id_cliente`, `Nombre_Cliente`, `Apellidos_Cliente`, `Email`, `Password`, `created_at`, `updated_at`, `idRol`) VALUES
(2, 'Tania', 'Jiménez', 'tania1@gmail.com', 'tania123', '1999-10-10', '1999-10-10', 1),
(3, 'Jose  De Jesus', 'Garcia Orozco', 'jesuus@gmail.com', 'joss1234', '1999-10-10', '1999-10-10', 2),
(4, 'Bryan', 'Rubio', 'bryanRubio@gmail.com', '123', '2020-07-30', '2020-07-30', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_pedido`
--

DROP TABLE IF EXISTS `detalle_pedido`;
CREATE TABLE IF NOT EXISTS `detalle_pedido` (
  `id_detalle_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad_producto` int(11) NOT NULL,
  `precio_compra` int(11) NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id_detalle_pedido`),
  KEY `fk_id_ped` (`id_pedido`),
  KEY `fk_id_prod` (`id_producto`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `detalle_pedido`
--

INSERT INTO `detalle_pedido` (`id_detalle_pedido`, `id_pedido`, `id_producto`, `cantidad_producto`, `precio_compra`, `subtotal`) VALUES
(1, 2, 4, 1, 0, '1069.93'),
(2, 3, 4, 1, 0, '1069.93'),
(3, 3, 2, 2, 0, '1012.84'),
(4, 3, 3, 1, 0, '1069.93'),
(5, 3, 6, 1, 0, '469.72'),
(6, 3, 7, 1, 0, '422.71'),
(7, 3, 8, 1, 0, '168.21'),
(8, 3, 1, 1, 0, '529.76'),
(9, 4, 2, 1, 0, '506.42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

DROP TABLE IF EXISTS `empleado`;
CREATE TABLE IF NOT EXISTS `empleado` (
  `id_empleado` int(11) NOT NULL AUTO_INCREMENT,
  `NSS` bigint(20) NOT NULL,
  `Nombre_Empleado` varchar(100) NOT NULL,
  `Apellidos_Empleado` varchar(100) NOT NULL,
  `Puesto` varchar(30) NOT NULL,
  `Email_Empleado` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `Telefono_Empleado` varchar(20) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  PRIMARY KEY (`id_empleado`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

DROP TABLE IF EXISTS `pago`;
CREATE TABLE IF NOT EXISTS `pago` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `Monto` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id_pago`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

DROP TABLE IF EXISTS `pedido`;
CREATE TABLE IF NOT EXISTS `pedido` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) DEFAULT NULL,
  `id_pago` int(11) NOT NULL,
  `Estado` varchar(100) DEFAULT NULL,
  `Municipio` varchar(100) DEFAULT NULL,
  `Direccion` varchar(200) DEFAULT NULL,
  `Codigo_Postal` int(11) DEFAULT NULL,
  `Telefono` bigint(20) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `Estado_Actual` varchar(100) DEFAULT NULL,
  `Monto` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `fk_clie` (`id_cliente`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `pedido`
--

INSERT INTO `pedido` (`id_pedido`, `id_cliente`, `id_pago`, `Estado`, `Municipio`, `Direccion`, `Codigo_Postal`, `Telefono`, `created_at`, `updated_at`, `Estado_Actual`, `Monto`) VALUES
(1, 4, 0, 'México', 'Tepito', 'avenida patria #2239', 32123, 3322456789, '2020-07-30', '2020-07-30', 'Pendiente', '506.42'),
(2, 4, 0, 'Jalisco', 'Guadalajara', 'Platanar #2239', 44599, 3356890652, '2020-07-30', '2020-07-30', 'Pendiente', '1069.93'),
(3, 4, 0, 'Jalisco', 'tonala', 'avenida tecualtita #3345', 32433, 3245678987, '2020-07-30', '2020-07-30', 'Pendiente', '4743.10'),
(4, 4, 0, 'México', 'dsfhjdfgnbvzfsghgfnbvzxcgbnmghfgxdfcv', '32425fdgnmgghfgdxf', 32453, 5467869976, '2020-07-30', '2020-07-30', 'Pendiente', '506.42');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

DROP TABLE IF EXISTS `producto`;
CREATE TABLE IF NOT EXISTS `producto` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `id_categoria` int(11) NOT NULL,
  `Nombre_Producto` varchar(100) NOT NULL,
  `Descripcion_Producto` text NOT NULL,
  `Marca` varchar(100) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Precio` decimal(8,2) NOT NULL,
  `Imagen_Producto` varchar(255) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `fk_id_cat` (`id_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `id_categoria`, `Nombre_Producto`, `Descripcion_Producto`, `Marca`, `Stock`, `Precio`, `Imagen_Producto`, `created_at`, `updated_at`) VALUES
(1, 1, 'FAR PERFECT M CELL EYES GEL ', 'Gel Contorno Ocular para desvanecer las líneas de expresión.', 'FARMA PIEL', 20, '529.76', 'p1.png', '2020-03-04', '2020-11-27'),
(2, 1, 'BDF LOC EUCERIN HYALU-FILL 30ML  ', 'Gel ultraligero y refrescante se absorbe rápidamente y deja la piel suave y con un aspecto saludable.', 'Dermamedina', 20, '506.42', 'p2.webp', '2020-03-04', '2020-11-27'),
(3, 1, 'FDL NEOSTRATA SKIN ACTIV SUERO  ', 'Suero para piel seca.', 'NeoStrata', 20, '1069.93', 'p3.webp', '2020-03-04', '2020-11-27'),
(4, 1, 'FDL NEOSTRATA SKIN ACTIV SUERO  ', 'Suero para piel seca.', 'NeoStrata', 20, '1069.93', 'p4.webp', '2020-03-04', '2020-11-27'),
(5, 1, 'BDF AGUA MICELLAIR 400ML PIEL SENSIBLE ', 'Agua para piel sensible.', 'Dermamedina', 20, '128.59', 'p5.jpg', '2020-03-04', '2020-11-27'),
(6, 1, 'ADV DERMAGE LIMP HIDRONUT PED ', 'Gel Limpiador hidronutritico pediatrico.', 'Dermamedina', 20, '469.72', 'p6.jpg', '2020-03-04', '2020-11-27'),
(7, 1, 'BIO ABCDERM H2O 1L ', 'Agua limpiadora y ultrasuave, para el rostro y los ojos de bebés.', 'Bioderma', 20, '422.71', 'p7.png', '2020-03-04', '2020-11-27'),
(8, 1, 'BIO SENSIBIO GEL MOUSSANT100ML ', 'Gel limpiador suave con acción hidratante y calmante.', 'Sensibio', 20, '168.21', 'p8.png', '2020-03-04', '2020-11-27'),
(9, 1, 'CAN BIRETIX BARRA DERMA80G ', 'Barra para higiene diaria de las pieles mixtas, grasas y con tendencia acnóica.', 'Dermamedina', 20, '95.45', 'p9.jpg', '2020-03-04', '2020-11-27'),
(10, 1, 'CAN ENDOCARE AQUAFOAM -125ML ', 'Solución micelar en espuma de IFC indicada para la limpieza diaria de todo tipo de pieles.', 'Endocare', 20, '388.76', 'p10.jpg', '2020-03-04', '2020-11-27'),
(11, 1, 'DAILYDERM LINE LADER GEL 50G PARA ROSTRO Y CUELLO ', 'Gel hialuronico permite niveles de hidratación profundos y completos.', 'Dermamedina', 20, '799.81', 'p11.png', '2020-03-04', '2020-11-27'),
(12, 1, 'DOAK JAB FORMULA 405 100GR ', 'Barra de jabón que limpia profundamente la piel hidratándola al mismo tiempo.', 'Doak', 20, '144.59', 'p12.png', '2020-03-04', '2020-11-27'),
(13, 2, 'LULLAGE RICH HYDRA INTEN 24H SOLUCION 50ML ', 'Hydra rich solution está formulada con una combinación de activos que proporciona una hidratación instantánea, intensa y duradera durante 24h a través de un sistema de liberación inteligente que administra la dosis justa de hidratación necesaria.', 'FARMA PIEL', 20, '421.79', 'm1.jpg', '2020-03-04', '2020-11-27'),
(14, 2, 'SKINVITA SERUM FACIAL TEN 50ML', 'Brinda propiedades antioxidantes y/o especificas en cada uno de sus componentes para restaurar la salud de la piel.', 'DermaFemina', 20, '518.54', 'm2.webp', '2020-03-04', '2020-11-27'),
(15, 2, 'FDL NEOSTRATA ENLIGHTEN SUERO 30ML', 'Aporta luminosidad a la piel que está afectada por hiperpigmentaciones causadas por la edad, cambios hormonales y exposición a los rayos UV.', 'NeoStrata', 20, '983.38', 'm3.jpg', '2020-03-04', '2020-11-27'),
(16, 2, 'ISD UREADIN FUSION SERUM LIFT ANTIARRUGAS 30ML', 'Ureadin Fusion Serum Lift Antiarrugas potencia la capacidad regeneradora de tu piel, ofreciendo resultados visibles en sólo 4 semanas.', 'NeoStrata', 20, '510.76', 'm4.webp', '2020-03-04', '2020-11-27'),
(17, 2, 'FBR AV COUV FONDO MIEL 30MLL', 'Formulado para pieles sensibles que buscan un maquillaje sin riesgo.', 'DermaFemina', 20, '434.43', 'm5.png', '2020-03-04', '2020-11-27'),
(18, 2, 'FBR AV COUV COMP CONF BRONCEA', 'Maquillaje con efecto aterciopelado sin riesgo de irritación durante la aplicación.', 'DermaFemina', 20, '498.61', 'm6.png', '2020-03-04', '2020-11-27'),
(19, 2, 'ISD WOMAN ANTIESTRIAS 250 ML', ' Antiestrías es una crema corporal antiestrías de rápida absorción.  ', 'DermaFemina', 20, '349.36', 'm7.jpg', '2020-03-04', '2020-11-27'),
(20, 2, 'MUSTELA MATERNA FIRMEZA CORP 200 ML', 'El Gel firmeza corporal, específicamente formulado para las recientes mamás, tonifica y reafirma la piel.', 'DermaFemina', 20, '265.95', 'm8.jpg', '2020-03-04', '2020-11-27'),
(21, 2, 'SESD ESTRYSES CRA ANTIESTRIAS 200ML', 'Tratamiento de las estrías causadas por el embarazo, lactancia, sobrepeso, dietas, deportes.', 'Dermamedina', 20, '715.31', 'm9.jpg', '2020-03-04', '2020-11-27'),
(22, 2, 'DSL OLIGO DX CELULIT GEL 150ML', 'Gel reductor de la celulitis que incorpora los mejores activos en un vehículo de nanosomas. ', 'Dermamedina', 20, '487.15', 'm10.png', '2020-03-04', '2020-11-27'),
(23, 2, 'UNI CP-CREMA HD ETAPA AVANZADA 200 ML', 'Crema ayuda a contrarrestar la aparición de imperfecciones debido a los depósitos de grasa localizados y la pérdida de elasticidad de la piel. ', 'Dermamedina', 20, '1239.69', 'm11.jpg', '2020-03-04', '2020-11-27'),
(24, 2, 'UNI CP-GEL CORP EXFOLIANTE TON 450 G', 'Exfoliante de tratamiento de belleza para el cuerpo. ', 'Dermamedina', 20, '622.32', 'm12.jpg', '2020-03-04', '2020-11-27'),
(25, 3, 'AKESIA NUFEM SUPLEMENTO 14 SOB ', 'Suplemento alimenticio que ayuda a disminuir los síntomas de la menopausia.', 'Dermamedina', 20, '330.99', 'cu1.png', '2020-03-04', '2020-11-27'),
(26, 3, 'ATACHE PLESINOX 30 CAPS  ', 'ATACHE PLESINOX 30 CAPS.', 'Dermamedina', 20, '501.60', 'cu2.png', '2020-03-04', '2020-11-27'),
(27, 3, 'FAR SODIMEL CAPS 60 ', 'Antioxidante Natural. Auxiliar en la prevención del fotodaño y el envejecimiento prematuro.', 'NeoStrata', 20, '1120.38', 'cu3.png', '2020-03-04', '2020-11-27'),
(28, 3, 'FDL OXYPROLANE CAPSULAS  ', 'Suplemento alimenticio que contribuye al proceso de cicatrización.', 'Dermamedina', 20, '609.93', 'cu4.png', '2020-03-04', '2020-11-27'),
(29, 3, 'GENOVE PILOPEPTAN CAPS 60  ', 'Pilopeptan cápsulas es un complemento alimenticio que aporta al organismo los componentes.', 'Dermamedina', 20, '915.67', 'cu5.jpg', '2020-03-04', '2020-11-27'),
(30, 3, 'DSL KERAMENE 180ML  ', 'Indicado para hombres y Mujeres e inhibe el crecimiento del vello, reduciendo la frecuencia de afeitarse.', 'NEOSTRATA', 20, '486.34', 'cu6.png', '2020-03-04', '2020-11-27'),
(31, 3, 'NOREVA KERAPIL KERATOREGULADOR CRA 75ML ', 'Depilación Cuidado, para eliminar límite rugosidad pelos encarnados.', 'Dermamedina', 20, '748.23', 'cu7.jpg', '2020-03-04', '2020-11-27'),
(32, 3, 'SESD HIDRALOE GEL DE ALOE 250ML ', 'Hidraloe Gel de Aloe hidrata, refresca, alivia, suaviza y protege la piel.', 'Dermamedina', 20, '256.75', 'cu8.jpg', '2020-03-04', '2020-11-27'),
(33, 3, 'BDF EUCERIN JBN INTIMO LIQ 250', 'Jabon liquido de limpueza suave', 'Dermamedina', 20, '646.32', 'cu9.png', '2020-03-04', '2020-11-27'),
(34, 3, 'DSL NIRENA HIG INTIM GEL 205ML', 'Gel orgánico, hipoalergénico especialmente diseñado para la higiene íntima femenina.', 'Dermamedina', 20, '185.66', 'cu10.png', '2020-03-04', '2020-11-27'),
(35, 3, 'FAR VAGIGEL GEL 100ML', 'Jabón de higiene íntima.', 'Dermamedina', 20, '436.34', 'cu12.jpg', '2020-03-04', '2020-11-27'),
(37, 4, 'LRE VICHY HOMME DESOD INTENSO', 'Desodorante anti-transpirante 72 h para pieles sensibles.', 'DERMAMEDINA ', 20, '337.16', 'h1.png', '2020-03-04', '2020-11-27'),
(38, 4, 'SESD HIDRALOE GEL DE ALOE 250ML', 'Hidraloe Gel de Aloe hidrata, refresca, alivia, suaviza y protege la piel. Recomendado para después de la exposición solar y tras la práctica de deportes de invierno (frío, viento...). ', 'DERMAMEDINA ', 20, '492.35', 'h3.jpg', '2020-03-04', '2020-11-27'),
(39, 4, 'BDF CRA EUCERIN HYALU-F CBOOST', 'Suero antienvejecimiento con 10% de Vitamina C pura y recién activada para todo tipo de pieles y está clínica mente y dermatológicamente comprobado para fortalecer la piel y rellenar arrugas.', 'DERMAMEDINA ', 20, '391.12', 'h2.webp', '2020-03-04', '2020-11-27'),
(40, 4, 'PAY SOIN APAISANT RASAG 50ML', 'Payot Homme Calmante Care After-Shave 50ml es un bálsamo para después del afeitado que calma y repara, sin alcohol.', 'DERMAMEDINA ', 20, '571.40', 'h4.jpg', '2020-03-04', '2020-11-27'),
(41, 4, 'LRE VICHY HOMME DESOD INTENSO', 'Desodorante anti-transpirante 72 h para pieles sensibles.', 'DERMAMEDINA ', 20, '337.16', 'h10.png', '2020-03-04', '2020-11-27'),
(42, 4, 'SESD DRYSES DESOD ANTITRANSP HOMBRE 75ML', 'Desodorante con una excelente tolerancia que modera la sudoración y el mal olor corporal de forma biológica.', 'DERMAMEDINA ', 20, '414.45', 'h6.jpg', '2020-03-04', '2020-11-27'),
(43, 4, 'FBR AV GEL P/AFEITAR 2011 150M', 'Crema de afeitado diario de las pieles sensibles del caballero.', 'DERMAMEDINA ', 20, '321.38', 'h7.png', '2020-03-04', '2020-11-27'),
(44, 4, 'MADE KIT BALSAMO+BODY WASH', 'Tratamiento para hombres.', 'DERMAMEDINA ', 20, '663.48', 'h8.jpg', '2020-03-04', '2020-11-27'),
(45, 4, 'PAY RASAGE PRECIS SPRY 100ML', 'Gel protector de espuma ultra-confort para el afeitado. ', 'DERMAMEDINA ', 20, '365.18', 'h9.jpg', '2020-03-04', '2020-11-27'),
(47, 4, 'LRE VICHY HOMME HYDRAMAG C', 'Tratamiento hidratante y anti-fatiga para rostro y ojos.', 'DERMAMEDINA ', 20, '513.16', 'h11.png', '2020-03-04', '2020-11-27'),
(48, 4, 'MAN MADE BODY WASH SPORT', 'Shampo que contiene glicerina natural, aceite de almendras y vitamina E', 'DERMAMEDINA ', 20, '209.13', 'h12.png', '2020-03-04', '2020-11-27'),
(49, 5, 'AMINOTER MAX SH 300 ML ', 'Shampo que ayuda en Reparación y Protección Capilar en Microesferas.', 'FARMA PIEL', 20, '588.10', 'c1.png', '2020-03-04', '2020-11-27'),
(50, 5, 'CAN IRALTONE LOC FORTI ANTICAI 125ML', 'Loción Fortificante es el tratamiento ideal para combatir la caída del cabello y/o fragilidad capilar tanto en hombres como en mujeres.', 'Dermamedina', 20, '443.41', 'c2.jpg', '2020-03-04', '2020-11-27'),
(51, 5, 'DSL POLARIS NR02 SHAMPO 210ML  ', 'Shampoo con tratamiento integral, con alta eficacia, y clínicamente comprobado.', 'Dermamedina', 20, '568.66', 'c3.jpg', '2020-03-04', '2020-11-27'),
(52, 5, 'DSL POLARIS NR11 TOPICO 60 ML  ', 'Tratamiento integral para alopecia androgenética', 'Dermamedina', 20, '655.04', 'c4.jpg', '2020-03-04', '2020-11-27'),
(53, 5, 'DSL REVITA COR 205 ML ', 'Tratamiento auxiliar para la pérdida de cabello en hombres y mujeres.', 'Dermamedina', 20, '382.77', 'c5.png', '2020-03-04', '2020-11-27'),
(54, 5, 'DSL REVITA GEL ANTICAIDA 100ML ', 'Gel anticaida contiene ingredientes activos que ayudan a potenciar la vitalidad del cabello.', 'Dermamedina', 20, '302.87', 'c6.jpg', '2020-03-04', '2020-11-27'),
(55, 5, 'DSL REVITA SH 180 ML ', 'Shampoo que estimula eficazmente el crecimiento del cabello, detiene su caída y engrosa el cabello.', 'Dermamedina', 20, '377.52', 'c7.jpg', '2020-03-04', '2020-11-27'),
(56, 5, 'DSL SPECTRAL DNC SPRAY 60ML ', 'Tratamiento tópico  para combatir  la pérdida del cabello, efectivo en la alopecia androgónica.', 'Dermamedina', 20, '556.78', 'c8.jpg', '2020-03-04', '2020-11-27'),
(57, 5, 'FAR ALOSTET LOCION AMP 10 ', 'Combinación de productos de origen herbal y vitaminas que actúa en los puntos claves del proceso de la alopecia androgenética', 'Dermamedina', 20, '826.78', 'c9.png', '2020-03-04', '2020-11-27'),
(58, 5, 'FAR ALOSTET SH 200ML ', 'Shampoo es un tratamiento recomendado para combatir la caída, estimular el crecimiento', 'Dermamedina', 20, '499.73', 'c10.png', '2020-03-04', '2020-11-27'),
(59, 5, 'FBR DU ANAPHASE ENJUAGUE 200ML ', 'Acondicionador ideal en complemento de tu shampoo anticaida.', 'Dermamedina', 20, '359.06', 'c11.png', '2020-03-04', '2020-11-27'),
(60, 5, 'FBR DU NEOPTIDE LOC ANTIC 3X30 ', 'Loción para luchar contra la caída del cabello del hombre.', 'Dermamedina', 20, '802.46', 'c12.png', '2020-03-04', '2020-11-27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

DROP TABLE IF EXISTS `rol`;
CREATE TABLE IF NOT EXISTS `rol` (
  `idrol` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(20) NOT NULL,
  PRIMARY KEY (`idrol`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`idrol`, `rol`) VALUES
(1, 'Administrador'),
(2, 'Cliente');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
