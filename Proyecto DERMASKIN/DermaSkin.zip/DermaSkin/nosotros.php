
<?php 
require_once "templates/links.php";
require_once "templates/header.php";
require_once "templates/carrusel.php";?>

<br>
<div class="container">
<section id="best-features" class="text-center">
  <br><br>

  <div class="row d-flex justify-content-center mb-4">
    <div class="col-md-12">
    <section>
        <div><img src="assets/img/quienes.png" width="550" height="150"></div>
    </section>

    <p class="grey-text"><h4>Somos una empresa familiar reconocida por nuestro amplio conocimiento en el área del 
      cuidado de la piel <br> contamos con más de 10 años de experiencia.</p>
    <br>
    <p class="grey-text"><h4>Nos especializamos nos preocupamos por la prevención de las enfermedades de la piel y de la preservación o la recuperación de la normalidad cutánea, así como de la dermocosmética que se dedica a la higiene, a la apariencia y protección de la piel.
</h4></p>

    </div>
    <!--Grid column-->

  </div>
  <!--Grid row-->

  <!--Grid row-->
  <style>
#cajaNormal {
  width: 90%;
  border: 3px;
  margin: 70px 70px;
  
}
</style>
<div id="cajaNormal">
<div class="arrivals">
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="section_title_container text-center">
        <section>
<div><img src="assets/img/nosotros2.jpg" width="550" height="150"></div>
</section>
        </div>
      </div>
    </div>
    <div class="row products_container">

      <!-- Empresa -->
      <div class="col-lg-4 product_col">
        <div class="product">
          <div class="product_image">
            <img src="assets/img/p2.webp" alt="" height="317px">
          </div>
          <div class="product_content clearfix">
            <div class="product_info">
            <h4 class="my-4 font-weight-bold">Experiencia</h4>
              <div class="product_name"><p align="justify">Derma Skin es una empresa familiar con 10 años al servicio de la Dermatología. Derma skin contiene innovación dermocosmética y experta en piel cutánea. </p></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Product -->
      <div class="col-lg-4 product_col">
        <div class="product">
          <div class="product_image">
            <img src="assets/img/h2.webp" alt="" height="317px">
          </div>
          <div class="product_content clearfix">
            <div class="product_info">
            <h4 class="my-4 font-weight-bold">Misión</h4>
              <div class="product_name"><p align="justify">Satisfacer las necesidades de nuestros clientes ofreciéndoles productos personalizados para cada tipo de piel formulados para mejorar su calidad de vida.</p></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Product -->
      <div class="col-lg-4 product_col">
        <div class="product">
          <div class="product_image">
            <img src="assets/img/p1.png" alt="" height="317px">
          </div>
          <div class="product_content clearfix">
            <div class="product_info">
            <h4 class="my-4 font-weight-bold">Visión</h4>
              <div class="product_name"><p align="justify">Desarrollar y popularizar los productos 100% naturales y concienciar de los beneficios de emplear productos cosméticos con componentes ecológicos.</p></div>
            </div>
          </div>
        </div>
      </div>
  </div>
  </div>
  <!--Grid row-->

</section>

<hr class="my-5">

<!--Section: Gallery-->
<section id="gallery">

  <!-- Heading -->
  <h2 class="mb-5 font-weight-bold text-center">Comentarios de Nuestros Clientes</h2>

  <!-- Section: Testimonials v.1 -->
  <section class="text-center p-1">
            <div class="row">

                <!--Grid column-->
                <div class="col-lg-4 col-md-12 mb-lg-0 mb-4">
                    <!--Card-->
                    <div class="card testimonial-card">
                        <!--Background color-->
                        <div class="card-up info-color"></div>
                        <!--Avatar-->
                        <div class="avatar mx-auto white">
                            <img src="assets/img/andres.jpeg" class="rounded-circle img-fluid" style="max-width:75%;">
                        </div>
                        <div class="card-body">
                            <!--Name-->
                            <h4 class="font-weight-bold mb-4">Andres Amezquita</h4>
                            <hr>
                            <!--Quotation-->
                            <p class="dark-grey-text mt-4 text-justify" style="font-size:17px;"><i class="fas fa-quote-left pr-2"></i>
                                En mi familia tenemos 5 años tratando nuestra piel en DermaSkin, son muy profesionales y a todos nos han funcionado sus tratamientos. 100% Recomendado.</p>
                        </div>
                    </div>
                    <!--Card-->
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-4 col-md-12 mb-lg-0 mb-4">
                    <!--Card-->
                    <div class="card testimonial-card">
                        <!--Background color-->
                        <div class="card-up info-color"></div>
                        <!--Avatar-->
                        <div class="avatar mx-auto white">
                            <img src="assets/img/ruby.jpeg" class="rounded-circle img-fluid" style="max-width:75%;" >
                        </div>
                        <div class="card-body">
                            <!--Name-->
                            <h4 class="font-weight-bold mb-4">Ruby Alvarez</h4>
                            <hr>
                            <!--Quotation-->
                            <p class="dark-grey-text mt-4 text-justify" style="font-size:17px;"><i class="fas fa-quote-left pr-2"></i>
                                Quede muy contenta con mi tratamiento, mi acné ha desaparecido y mi piel luce hermosa y saludable.</p>
                        </div>
                    </div>
                    <!--Card-->
                </div>
                <div class="col-lg-4 col-md-6">
                    <!--Card-->
                    <div class="card testimonial-card">
                        <!--Background color-->
                        <div class="card-up indigo"></div>
                        <!--Avatar-->
                        <div class="avatar mx-auto white">
                            <img src="assets/img/alfredo.jpeg" class="rounded-circle img-fluid" style="max-width:75%;">
                        </div>
                        <div class="card-body">
                            <!--Nombre-->
                            <h4 class="font-weight-bold mb-4">Alfredo Serrano</h4>
                            <hr>
                            <!--Comentario-->
                            <p class="dark-grey-text mt-4 text-justify" style="font-size:17px;"><i class="fas fa-quote-left pr-2"></i>Excelente servicio, son muy profesionales, no cabe duda que su experiencia habla por sí sola lo recomiendo.</p>
                        </div>
                    </div>
                    <!--Card-->
                </div>

            </div>

        </section>

<hr class="my-5">



</div>
</body>
<?php require_once "templates/footer.php";?>

