<?php 
    require_once 'config/conexion.php';
    require_once "templates/header.php";
    require_once "templates/links.php";
    //require_once __DIR__. '/vendor/autoload.php';
   
    //use Spipu\Html2Pdf\Html2Pdf;
    //$html2pdf = new Html2Pdf();
    //$html2pdf->writeHTML('<h1>Hola Mundo desde un pdf</h1>');
    
    //$html2pdf->output('pdf_generate.pdf');
   
    $idPedido = $_GET['pedido'];

    $sql = "SELECT p.*, dp.*, ped.* FROM producto p 
    INNER JOIN detalle_pedido dp ON (p.id_producto=dp.id_producto) 
    INNER JOIN pedido ped ON (ped.id_pedido=dp.id_pedido) 
    WHERE dp.id_pedido=$idPedido";

    $query = mysqli_query($con,$sql);
?>


<style>
#cajaNormal {
  width: 90%;
  border: 3px;
  margin: 30px 60px;  
}
</style>

   <div id="cajaNormal">
<h3>Detalle del pedido</h3>

<table class="table table-light table-hover">
    <tbody>
        <tr>
            <th width="30%" class="text-center">Imagen </th>
            <th width="30%" class="text-center">Nombre Producto </th>
            <th width="10%" class="text-center">Cantidad </th>
            <th width="15%" class="text-center">Precio </th>
            <th width="15%" class="text-center">Subtotal </th>
        </tr>
        <?php $total=0;?>
        <!-- Por cada pedido en el arreglo de la bd va a imprimir una fila con los datos -->
        <?php while ($producto = mysqli_fetch_array($query)): ?>
        <tr>
            <td width="30%" class="text-center"><img src="assets/img/<?= $producto['Imagen_Producto'] ?>" alt="" style="max-width:15%;"></a></td>
            <td width="30%" ><?= $producto['Nombre_Producto']?></td>
            <td width="10%" class="text-center"><?= $producto['cantidad_producto']?></td>
            <td width="15%" class="text-center"><?= $producto['Precio']?></td>
            <td width="15%" class="text-center"><?= $producto['subtotal']?></td>
        </tr>
        <?php $total=$total+($producto['Precio']*$producto['cantidad_producto']);?>
            <?php endwhile; ?>
            <tr>
            <td colspan="4" align="right"><h3>Total Pagado</h3></td>
            <td align="right"><h3>$<?php echo number_format($total,2); ?></h3></td>
            
        </tr>
    </tbody>  
</table>
</div>
<br><br><br><br><br><br><br>
<?php require_once "templates/footer.php";?>