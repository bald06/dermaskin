<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Derma Skin | Artículos Dermatológicos</title>
    
    <?php require_once "links.php";?>
<body>

<!--APIs Redes sociales-->
<div class="sociales">
   <ul>
    <li><a href="https://www.facebook.com/juanmanuel.dermaskin.9" target="_blank" class="fab fa-facebook-f"style="color: #fff"></a></li>
    <li><a href="https://m.me/juanmanuel.dermaskin.9" target="_blank" class="fab fa-facebook-messenger" style="color: #fff"></a></li>
    <li><a href="https://api.whatsapp.com/send?phone=5213326151405&text=Hola%20Derma%20Skin" target="_blank" class="fab fa-whatsapp" style="color: #fff"></a></li>
    </ul>
   </div>
<!--cierre de apis-->

<nav class="navbar navbar-expand-lg navbar-light bg-light">
&nbsp;&nbsp;&nbsp;
  <link rel="shortcut icon" type="image/png" href="assets/img/logo.png">
  <a class="navbar-brand" href="#">
    <img id="logo" src="assets/img/logo.png" style="max-width: 70px; max-height:70px;" >
  </a>
  <a class="navbar-brand" href="index.php">Derma Skin</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Categorías
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="piel.php">Cuidado de la piel</a>
          <a class="dropdown-item" href="mujer.php">Mujer</a>
          <a class="dropdown-item" href="hombre.php">Hombre</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="cuerpo.php">Cuerpo</a>
          <a class="dropdown-item" href="cabello.php">Cebello</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Nosotros
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="nosotros.php">¿Qué es Derma Skin?</a>
          <a class="dropdown-item" href="doctor/index.php">Nuestros Servicios</a>
          <a class="dropdown-item" href="contacto.php">Contacto</a>
        </div>
      </li>
    </ul>

    <form class="form-inline my-2 my-lg-0" id="form">
    <ul class="navbar-nav mr-auto">
    <!-- Si el usuario esta logeado muestra su nombre, si no muestra 'iniciar sesion' -->
    <?php if(isset($_SESSION['logindat'])): ?>
      <img class="photouser" src="assets/img/user.ico" alt="Usuario" style=" max-width: 30px; max-height:30px;" >		
    <li class="nav-item">
        <a class="nav-link" href="#" >Bienvenido&nbsp;<?= $_SESSION{'logindat'}['Nombre_Cliente']?></a>
      </li>&nbsp;&nbsp;&nbsp;
      <li class="nav-item">
        <a class="nav-link" href="compra.php" >Mis pedidos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="cerrar.php" >Cerrar Sesión</a>
      </li>
    <?php else: ?>
      <li class="nav-item">
        <a class="nav-link" href="registro.php" >Iniciar Sesión</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="registroUsuarios.php" >Registrarse </a>
      </li>
    <?php endif;?>
      
      </li>
    </ul>&nbsp;&nbsp;
    <li class="nav-item" style="list-style:none;">
    <style type="text/css" media="screen">
        A:link {text-decoration: none }
        A:visited {color: black;  font-family: arial; text-decoration: none }
    </style>
  
    </li> 
    <?php if(isset($_SESSION['logindat'])): ?>
    <?php
    $totalProductos = 0;
      if(isset($_SESSION['CARRITO'])){
        

        foreach($_SESSION['CARRITO'] as $producto){
          $totalProductos+=$producto['Cantidad'];
        }
      }
    ?>
      <a href="mostrar.php"><img  src="assets/img/carrito.png" style=" max-width: 30px; max-height:30px; " >(<?php
                    echo (empty($_SESSION['CARRITO']))?0:$totalProductos;
                ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<th></a>
    </li>
    </li>
    <?php endif;?>
    </form>
  </div>
</nav>