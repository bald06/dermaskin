<?php require_once "links.php";?>
<!-- Footer -->
<footer class="page-footer font-small blue-grey lighten-5">

  <div style="background-color: #21d192;">
    <div class="container">

      <!-- Grid row-->
      <div class="row py-4 d-flex align-items-center">

        <!-- Grid column -->
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          <h4 class="mb-0">Conéctate con nosotros!</h4>
        </div>
      </div>
    </div>
  </div>

  <!-- Footer Links -->
  <div class="container text-center text-md-left mt-5">

    <!-- Grid row -->
    <div class="row mt-3 dark-grey-text">

      <!-- Grid column -->
      <div class="col-md-3 col-lg-4 col-xl-3 mb-4">

        <!-- Content -->
        <h6 class="text-uppercase font-weight-bold">Derma Skin</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p align="justify">Nos especializamos y preocupamos por la prevención de las enfermedades y la recuperación de la normalidad cutánea, 
          así como de la dermocosmética que se dedica a la higiene, apariencia y protección de la piel.</p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Categorías</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a class="dark-grey-text" href="piel.php">Piel</a>
        </p>
        <p>
          <a class="dark-grey-text" href="mujer.php">Mujer</a>
        </p>
        <p>
          <a class="dark-grey-text" href="hombre.php">Hombre</a>
        </p>
        <p>
          <a class="dark-grey-text" href="cuerpo.php">Cuerpo</a>
        </p>

      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold">Contactanos</h6>
        <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <i class="contact-list"></i>Nicolás Romero 844-A <br>
          <i class="contact-list"></i> Col. Villaseñor Guadalajara Jalisco </p>
        <p>
          <i class="fas fa-envelope mr-3"></i> dermaSkin_info@gmail.com</p>
          <dl class="contact-list">
                        <dt>TELÉFONO:</dt>
                        <dd><a href="tel:#">+52 1 33 1442 1242</a> <span></a>
                        </dd>
                      </dl>
      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
      <div class="col-md-4 col-xl-3">
                      <h5>  </h5>
                    <img class="brand-logo-light" src="assets/img/logo.png" alt="" width="250" height="200" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                    </div>
        
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center text-black-50 py-3">© 2020 Copyright:
    <a class="dark-grey-text" href="DermaSkin"> DermaSkin</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
<script src='./producto.js'></script>