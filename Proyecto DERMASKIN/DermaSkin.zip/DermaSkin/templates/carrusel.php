<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="imagenes/img2.jpg" alt="Cuidado Piel" width="1700" height="500">
      <div class="carousel-caption">
      <h1 class="font-weight-bold mb-4"><font color="Teal" face="arial,verdana">Mascarrilla de Carbón Activado</font></h1>
      <p><h4><font color="Black" face="arial,verdana">Ven y conoce los beneficios del carbón activado</font></h4></p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="imagenes/img1.jpg" alt="Cuidado Men" width="1700" height="500">
      <div class="carousel-caption">
      <h1 class="font-weight-bold mb-4"><font color="Teal" face="arial,verdana">Mascarrilla de Arcilla</font></h1>
      <p><h4><font color="Black" face="arial,verdana">Ven y conoce los beneficios de la arcilla</font></h4></p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="imagenes/img3.jpg" alt="Agradecimiento" width="1700" height="500">
      <div class="carousel-caption">
      <h1 class="font-weight-bold mb-4"><font color="Teal" face="arial,verdana">Gracias por confiar en Derma Skin</font></h1>
        <p><h4><font color="Black" face="arial,verdana">Conocenos</font></h4></p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>