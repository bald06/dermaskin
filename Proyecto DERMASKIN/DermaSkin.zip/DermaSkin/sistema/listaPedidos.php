<?php
require_once "../config/conexion.php";
include "../templates/links.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
	

	<title>Lista de Pedidos</title>
</head>
<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <h1>Lista de Pedidos</h1>
        <table id="pedidos" class="table display table-striped table-bordered">
        <thead>
            <tr>
                <th class="th-sm">ID</th>
                <th class="th-sm">Cliente</th>
                <th class="th-sm">Dirección</th>
                <th class="th-sm">Teléfono</th>
                <th class="th-sm">Estatus</th>
                <th class="th-sm" width="15%">Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $query = mysqli_query($con,"SELECT * FROM Pedido");
            //validacion
            if ($query) {
                while ($data = mysqli_fetch_array($query)) {
                    
        ?>
            <tr>
                <td><?= $data['id_pedido'];?></td>
                <td><?= $data['id_cliente'];?></td>
                <td><?= $data['Direccion'];?></td>
                <td><?= $data['Telefono'];?></td>
                <td><?= $data['Estado_Actual'];?></td>
                <td>
                <button class="btn btn-outline-info"><a class="link_editar" href="editar_pedido.php?id=<?= $data['id_pedido'];?>">Editar  </a></button>
                <button class="btn btn-outline-danger"><a class="link_borrar" href="eliminar_Pedido.php?id=<?= $data['id_cliente'];?>">Eliminar</a></button>
                </td>
            </tr>
    <?php
        }
    }
    ?>
    </tbody>
        </table>
	</section>
</body>
</html>