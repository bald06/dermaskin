    <link rel="stylesheet" type="text/css" href="css/styles.css">
    <script type="text/javascript"src="js/functions.js"></script>
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <link rel="stylesheet" href="css/jquery.dataTables.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/table.js"></script>

    <?php include "functions.php"; ?>
    