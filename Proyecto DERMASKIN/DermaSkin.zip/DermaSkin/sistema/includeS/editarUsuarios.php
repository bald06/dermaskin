<?php
require_once "../../config/conexion.php";


    //Validar si llegan datos por POST

    if(isset($_POST)){
        $id = $_POST['idUsuario'];
        //Validar que no venga el campo vacio
        $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : false;
        $apellidos = isset($_POST['apellidos']) ? $_POST['apellidos'] : false;
        $email = isset($_POST['email']) ? $_POST['email'] : false;
        
        $rol = $_POST['rol'];


        if($nombre && $apellidos && $email){
            $sql = "UPDATE cliente SET Nombre_Cliente ='$nombre', Apellidos_Cliente='$apellidos', Email='$email', idrol=$rol WHERE id_cliente = $id";

            $query = mysqli_query($con,$sql);

            if($query){
                header('location:../lista_usuarios.php');
            }else{
                echo 'Err';
                die( print_r( sqlsrv_errors(), true));
            }
        }


    }
?>