<?php 
require_once '../config/conexion.php'; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drrma Skin | Artículos Dermatológicos</title>
    <link rel="shortcut icon" type="image/png" href="assets/img/logo.png">


<header>
		<div class="header">
			<h1>Sistema Para Administradores <br> Derma Skin</h1>
			<div class="optionsBar">
				<p>Guadalajara, <?php echo fechaC();?></p>
				<span>|</span>
				<!--  -->
				<img class="photouser" src="img/user_avatar.png" alt="Usuario">
				<a href="salir.php"><img class="close" src="img/salir.png" alt="Salir del sistema" title="Salir"></a>
			</div>
		</div>
		<?php include "nav.php"; ?>
	</header>
	</body>
	</html>