<nav>
			<ul>
				<li class="principal">
						<li><a href="lista_usuarios.php">Usuarios</a></li>
				</li>
				<li class="principal">	
						<li><a href="listaClientes.php">Clientes</a></li>
				</li>
				<li class="principal">
						<li><a href="listaProductos.php">Productos</a></li>
				</li>
				<li class="principal">
						<li><a href="nuevoProducto.php">Agregar producto</a></li>
				</li>
				<li class="principal">
						<li><a href="listaFaltantes.php">Consultar faltantes</a></li>
				</li>
			</ul>
		</nav>