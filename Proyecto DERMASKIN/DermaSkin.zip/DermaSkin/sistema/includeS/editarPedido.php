<?php
require_once "../../config/conexion.php";


    //Validar si llegan datos por POST

    if(isset($_POST)){
        $id = $_POST['idPedido'];
        //Validar que no venga el campo vacio
        $cliente = isset($_POST['cliente']) ? $_POST['cliente'] : false;
        $direccion = isset($_POST['direccion']) ? $_POST['direccion'] : false;
        $telefono = isset($_POST['telefono']) ? $_POST['telefono'] : false;
        $estatus = isset($_POST['estado_Actual']) ? $_POST['estado_Actual'] : false;
        
        

        if($cliente && $direccion && $telefono && $estatus){
            $sql = "UPDATE pedido SET id_cliente ='$cliente', Direccion='$direccion', Telefono='$telefono', Estado_Actual='$estatus' WHERE id_pedido = $id";
            
            $query = mysqli_query($con,$sql);
            
            if($query){
                header('location:../listaPedidos.php');
            }else{
                echo "Error";
                die( print_r( sqlsrv_errors(), true));
            }
        }


    }
?>