
<?php
require_once "../../config/conexion.php";


    //Validar si llegan datos por POST

    if(isset($_POST)){
        $idRol = $_POST['rol'];
        //Validar que no venga el campo vacio
        $nombre = isset($_POST['nombre']) ? $_POST['nombre'] : false;
        $apellidos = isset($_POST['apellidos']) ? $_POST['apellidos'] : false;
        $email = isset($_POST['correo']) ? $_POST['correo'] : false;
        $contrasenia = isset($_POST['clave']) ? $_POST['clave'] : false;

        
        $rol = $_POST['rol'];


        if($nombre && $apellidos && $email){
            $sql = "INSERT INTO Cliente (Nombre_Cliente,Apellidos_Cliente,Email,Password,idRol) 
            VALUES('$nombre','$apellidos','$email','$contrasenia',$idRol)";

            $query = mysqli_query($con,$sql);

            if($query){
                header('location:../lista_usuarios.php');
            }else{
                echo 'Err';
                die( print_r( mysqli_errors(), true));
            }
        }


    }
?>