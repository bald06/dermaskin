
<?php
require_once "../../config/conexion.php";


    //Validar si llegan datos por POST

    if(isset($_POST)){
        $id_categoria = isset($_POST['cat']) ? $_POST['cat'] : false;
        $Nombre_Producto = isset($_POST['Nombre_Producto']) ? $_POST['Nombre_Producto'] : false;
        $Descripcion_Producto = isset($_POST['Descripcion_Producto']) ? $_POST['Descripcion_Producto'] : false;
        $Marca = isset($_POST['Marca']) ? $_POST['Marca'] : false;
        $Stock = isset($_POST['Stock']) ? $_POST['Stock'] : false;
        $Precio = isset($_POST['Precio']) ? $_POST['Precio'] : false;
        $Imagen_Producto = isset($_POST['Imagen_Producto']) ? $_POST['Imagen_Producto'] : false;

        
        


        if($id_categoria && $Nombre_Producto  && $Descripcion_Producto && $Marca && $Stock && $Precio  && $Imagen_Producto){
            $sql ="INSERT INTO Producto (id_categoria, Nombre_Producto, Descripcion_Producto, Marca, Stock, Precio, Imagen_Producto) 
            VALUES($id_categoria,'$Nombre_Producto','$Descripcion_Producto','$Marca','$Stock','$Precio','$Imagen_Producto')";


            $query = mysqli_query($con,$sql);

            if($query){
                header('location:../listaProductos.php');
            }else{
                echo mysqli_error($con);
                die();
            }
        }


    }
?>