<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
    <title>Sistema de Administración</title>
    
</head>

<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <div class="form_register">
        <h1>Registro de nuevos productos</h1>
        <hr>
        <div class="alert"><?php echo isset($alert) ?$alert: ''; ?></div>
        <form action="includeS/registroProductos.php"  method="POST">
        
            <label for="categoria">Categoría</label>
            <?php
                $query_cat= mysqli_query($con,"SELECT * FROM categoria");
                $result_cat= mysqli_num_rows($query_cat);
            ?>
            
            <select name="cat" id="cat">
            <?php
                     while ($cat = mysqli_fetch_array($query_cat)) {
            ?>
                <option value="<?php echo $cat["id_categoria"];?>"><?php echo $cat["Nombre_categoria"] ?></option>
            <?php
                }
            ?>
            </select>
            </select>
            <label for="nombre">Nombre</label>
            <input type="text" name="Nombre_Producto" id="Nombre_Producto" placeholder="Nombre Producto">
            <label for="desc">Descripción</label>
            <input type="text" name="Descripcion_Producto" id="Descripcion_Producto" placeholder="Descripcion">
            <label for="marca">Marca</label>
            <input type="text" name="Marca" id="Marca" placeholder="Marca">
            <label for="stock">Stock</label>
            <input type="number" name="Stock" id="Stock" placeholder="Stock">
            <label for="precio">Precio</label>
            <input type="number" name="Precio" id="Marca" placeholder="Marca">
            <label for="imagen">Imágenes</label>
            <input name="Imagen_Producto" type="file" id="Imagen_Producto" ><br/>
            <input type="submit" value="Crear producto" class="btn_save">
        </form>
        </div>
	</section>
</body>
</html>

