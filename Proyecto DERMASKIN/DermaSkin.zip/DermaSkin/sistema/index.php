
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
	<?php require_once '../config/conexion.php'; ?>
	<title>Sistema de Administración</title>
</head>
<body>

<?php include "includeS/header.php"; ?>
<?php
	 if (!isset($_SESSION['logindat'])) {
		 header('location: ../');
	 }
?>
	<br><br>
	<section id="container">
	
	<h1>
		Bienvenido al sistema <?php echo $_SESSION['logindat'][1]?>
	</h1>
	</section>
</body>
</html>