<?php
require_once "../config/conexion.php";
include "../templates/links.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
	
	<title>Lista de Productos</title>
</head>
<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <h1>Lista de Productos</h1>
        <table id="productos" class="table display table-striped table-bordered">
            <!-- Ah y algo importante es que debes encerrar este tr de abajo en un thead , en todas las tablas lo debes de hacer  -->
            <thead>
            <tr>
                <th class="th-sm">ID</th>
                <th class="th-sm">Nombre</th>
                <th class="th-sm">Precio</th>
                <th class="th-sm">Descripcion</th>
                <th class="th-sm">Marca</th>
                <th class="th-sm">Stock</th>
            </tr>
            </thead>
            <tbody>
        <?php
            $query = mysqli_query($con,"SELECT u.*,p.* FROM producto u INNER JOIN categoria p ON u.id_categoria = p.id_categoria");
            //validacion
            if ($query) {
                while ($data = mysqli_fetch_array($query)) {
                    
        ?>
        <!-- y aqui debes encerrar este tr dentro de un tbody pero trata que la apertura y cierre queden afuera del while -->
            <tr>
                <td><?php echo $data['id_producto'];?></td>
                <td><?php echo $data['Nombre_Producto'];?></td>
                <td><?php echo $data['Precio'];?></td>
                <td><?php echo $data['Descripcion_Producto'];?></td>
                <td><?php echo $data['Marca'];?></td>
                <td><span class=<?= $data['Stock']<=5 ? "text-danger" : '' ?> ><?=  $data['Stock']<=5 ? $data['Stock'].' << POCO STOCK >> ' : $data['Stock']; ?></span></td> 
            </tr>
    <?php
        }
    }
    ?>
    </tbody>
        </table>
	</section>
</body>
</html>