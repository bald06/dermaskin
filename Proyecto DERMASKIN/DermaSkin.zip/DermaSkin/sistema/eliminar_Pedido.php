<?php
require_once "../config/conexion.php";

    if(isset($_GET)){
        $id = $_GET['id'];
            $sql = "DELETE FROM Pedido WHERE id_pedido=$id";

            $query = mysqli_query($con,$sql);

            if($query){
                header('location:listaPedidos.php');
            }else{
                echo 'Err';
                die( print_r( sqlsrv_errors(), true));
            }
        


    }
