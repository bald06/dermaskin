<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
    <title>Sistema de Administración</title>
    
</head>

<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <div class="form_register">
        <h1>Registro de usuarios</h1>
        <hr>
        <div class="alert"><?php echo isset($alert) ?$alert: ''; ?></div>
        <form action="includeS/registroUsuarios.php"  method="POST">
            <label for="nombre">Nombres</label>
            <input type="text" name="nombre" id="Nombre_Cliente" placeholder="Nombres">
            <label for="nombre">Apellidos</label>
            <input type="text" name="apellidos" id="Apellidos_Cliente" placeholder="Apellidos">
            <label for="correo">Correo electronico</label>
            <input type="email" name="correo" id="correo" placeholder="Cocorreo electronico">
            <label for="clave">Contraseña</label>
            <input type="password" name="clave" id="Password" placeholder="Contraseña">
            <label for="rol">Tipo de usuario</label>
            
            <?php
                $query_rol= mysqli_query($con,"SELECT * FROM rol");
                $result_rol= mysqli_num_rows($query_rol);
            ?>
            
            <select name="rol" id="rol">
            <?php
                     while ($rol = mysqli_fetch_array($query_rol)) {
            ?>
                <option value="<?php echo $rol["idrol"];?>"><?php echo $rol["rol"] ?></option>
            <?php
                }
            ?>
            </select>
            <input type="submit" value="Crear usuario" class="btn_save">
        </form>
        </div>
	</section>
</body>
</html>

