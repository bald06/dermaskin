<?php
require_once "../config/conexion.php";
include "../templates/links.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
	

	<title>Lista de Clientes</title>
</head>
<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <h1>Lista de clientes</h1>
        <a href="listaPedidos.php" class="btn_new">Ver pedidos</a>
        <table id="clientes" class="table display table-striped table-bordered">
        <thead>
            <tr>
                <th class="th-sm">ID</th>
                <th class="th-sm">Nombre</th>
                <th class="th-sm">Apellidos</th>
                <th class="th-sm">Correo</th>
                <th class="th-sm">Rol</th>
                <th class="th-sm"width="15%">Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $query = mysqli_query($con,"SELECT u.*, r.idRol FROM cliente u INNER JOIN rol r ON u.idRol = r.idrol
                where u.idrol=2");
            //validacion
            if ($query) {
                while ($data = mysqli_fetch_array($query)) {
                    
        ?>
            <tr>
                <td><?=$data['id_cliente'];?></td>
                <td><?=$data['Nombre_Cliente'];?></td>
                <td><?=$data['Apellidos_Cliente'];?></td>
                <td><?=$data['Email'];?></td>
                <td><?=$data['idRol'];?></td>
                <td>
                <button class="btn btn-outline-info"><a class="link_editar" href="editar_usu.php?id=<?= $data['id_cliente'];?>">Editar  </a></button>
                <button class="btn btn-outline-danger"><a class="link_borrar" href="eliminar_usu.php?id=<?=$data['id_cliente'];?>">Eliminar</a></button>
                </td>
            </tr>
    <?php
        }
    }
    ?>
    </tbody>
        </table>
	</section>
</body>
</html>