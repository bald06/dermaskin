
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
    <title>Editar Usuarios</title>
    
</head>

<body>
<?php include "includeS/header.php"; ?>
<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];

    $query = mysqli_query($con,"SELECT * FROM cliente WHERE id_cliente=$id");

    $user = mysqli_fetch_array($query);
}

?>
	<br><br>
	<section id="container">
        <div class="form_register">
        <h1>Editar Usuarios</h1>
        <hr>
        <div class="alert"><?php echo isset($alert) ?$alert: ''; ?></div>
        <form action="includeS/editarUsuarios.php"  method="POST">
            <input type="hidden" name="idUsuario" value="<?= $user['id_cliente']; ?>">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" placeholder="Nombre completo" value="<?= $user['Nombre_Cliente'] ?>">
            <label for="nombre">Apellidos</label>
            <input type="text" name="apellidos" id="apellidos" placeholder="Nombre completo" value="<?= $user['Apellidos_Cliente'] ?>">
            <label for="correo">Correo electronico</label>
            <input type="email" name="email" id="email" placeholder="Cocorreo electronico" value="<?= $user['Email'] ?>">
            <label for="rol">Tipo de usuario</label>
            
            <?php
                $query_rol= mysqli_query($con,"SELECT * FROM rol");
            ?>
            
            <select name="rol" id="rol" class="notItem">
            <?php while($rol = mysqli_fetch_array($query_rol)): ?>
                <option value="<?= $rol['idrol'] ?>"><?= $rol['rol'] ?></option>
            <?php endwhile;?>

            </select>
            <input type="submit" value="Guardar" class="btn_save" name="Submit">
        </form>
        </div>
	</section>
</body>
</html>

