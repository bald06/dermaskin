<?php
require_once "../config/conexion.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
	

	<title>Lista de Productos</title>
</head>
<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <h1>Lista de Productos</h1>
        <a href="registroProductos.php" class="btn_new">Buscar</a>
        <table>
            <tr>
                <th>ID</th>
                <th>Categoria</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Marca</th>
                <th>Stock</th>
                <th>Acciones</th>
            </tr>
        <?php
            $query = mysqli_query($con,"SELECT u.*,p.* FROM producto u INNER JOIN categoria p ON u.id_categoria = p.id_categoria");
            //validacion
            if ($query) {
                while ($data = mysqli_fetch_array($query)) {
                    
        ?>
            <tr>
                <td><?php echo $data['id_producto'];?></td>
                <td><?php echo $data['id_categoria'];?></td>
                <td><?php echo $data['Nombre_Producto'];?></td>
                <td><?php echo $data['Descripcion_Producto'];?></td>
                <td><?php echo $data['Marca'];?></td>
                <td><?php echo $data['Stock'];?></td>
                <td>
                    <a class="link_editar" href="editar_usu.php ? id=<?php echo $data['id_producto'];?>">Editar  </a>
                    <a class="link_borrar" href="eliminar_usu.php ? id=<?php echo $data['id_producto'];?>">Eliminar</a>
                </td>
            </tr>
    <?php
        }
    }
    ?>
        </table>
	</section>
</body>
</html>