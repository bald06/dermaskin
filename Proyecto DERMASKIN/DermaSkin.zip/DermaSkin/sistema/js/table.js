//De esta forma primero carga la pagina y luego el script
$(document).ready( function () {

    //Tabla usuarios
    $('#usuarios').DataTable({
        language:{
            info: '',
            infoEmpty:'',
            paginate: {
                first:      "Primero",
                previous:   "Anterior",
                next:       "Siguiente",
                last:       "Ultimo"
            },
            search:'Buscar',
            sLengthMenu : 'Mostrar _MENU_ Registros'
        }
    });

      //Tabla pedidos
      $('#pedidos').DataTable({
        language:{
            info: '',
            infoEmpty:'',
            paginate: {
                first:      "Primero",
                previous:   "Anterior",
                next:       "Siguiente",
                last:       "Ultimo"
            },
            search:'Buscar',
            sLengthMenu : 'Mostrar _MENU_ Registros'
        }
    });
     //Tabla clientes
     $('#clientes').DataTable({
        language:{
            info: '',
            infoEmpty:'',
            paginate: {
                first:      "Primero",
                previous:   "Anterior",
                next:       "Siguiente",
                last:       "Ultimo"
            },
            search:'Buscar',
            sLengthMenu : 'Mostrar _MENU_ Registros'
        }
    });
    //Tabla productos 
    $('#productos').DataTable({
        language:{
            info: '',
            infoEmpty:'',
            paginate: {
                first:      "Primero",
                previous:   "Anterior",
                next:       "Siguiente",
                last:       "Ultimo"
            },
            search:'Buscar',
            sLengthMenu : 'Mostrar _MENU_ Registros'
        }
    });
} );