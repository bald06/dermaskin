<?php
require_once "../config/conexion.php";

    if(isset($_GET)){
        $id = $_GET['id'];
            $sql = "DELETE FROM Cliente WHERE id_cliente=$id";

            $query = mysqli_query($con,$sql);

            if($query){
                header('location:lista_usuarios.php');
            }else{
                echo 'Err';
                die( print_r( sqlsrv_errors(), true));
            }
        


    }
