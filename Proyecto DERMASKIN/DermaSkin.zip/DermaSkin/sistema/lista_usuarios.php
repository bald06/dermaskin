<?php
require_once "../config/conexion.php";
include "../templates/links.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
	

    <title>Lista de usuarios</title>
   

</head>
<body>
<?php include "includeS/header.php"; ?>
	<br><br>
	<section id="container">
        <h1>Lista de usuarios</h1>
        <a href="registrousuarios.php" class="btn_new">Crear usuario</a>
        
        <table id="usuarios" class="table display table-striped table-bordered">
            <thead>
            <tr>
                <th class="th-sm">ID</th>
                <th class="th-sm">Nombre</th>
                <th class="th-sm">Apellidos</th>
                <th class="th-sm">Correo</th>
                <th class="th-sm">Rol</th>
                <th class="th-sm">Acciones</th>
            </tr>
            </thead>
            <tbody>
        <?php
            $query = mysqli_query($con,"SELECT u.*,
            r.* FROM cliente u INNER JOIN rol r ON u.idRol = r.idrol");
            //validacion
            if ($query) {
                while ($data = mysqli_fetch_array($query)) {
                    
        ?>
            
                <tr>
                    <td><?= $data['id_cliente'];?></td>
                    <td><?= $data['Nombre_Cliente'];?></td>
                    <td><?= $data['Apellidos_Cliente'];?></td>
                    <td><?= $data['Email'];?></td>
                    <td><?= $data['rol'];?></td>
                    <td>
                    <button class="btn btn-outline-info"><a class="link_editar" href="editar_usu.php?id=<?= $data['id_cliente'];?>">Editar  </a></button>
                    <button class="btn btn-outline-danger"><a class="link_eliminar" href="eliminar_usu.php?id=<?= $data['id_cliente'];?>">Eliminar</a></button>
                    </td>
                </tr>
            
    <?php
        }
    }
    ?>
    </tbody>
        </table>
    </section>
    
    
</body>
</html>