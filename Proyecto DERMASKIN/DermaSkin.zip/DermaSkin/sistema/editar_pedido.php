
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF8">
	<?php include "includeS/scripts.php"; ?>
    <title>Editar Pedido</title>
    
</head>

<body>
<?php include "includeS/header.php"; ?>
<?php
if(isset($_GET['id'])){
    $id = $_GET['id'];

    $query = mysqli_query($con,"SELECT * FROM pedido WHERE id_pedido=$id");

    $user = mysqli_fetch_array($query);
}

?>
	<br><br>
	<section id="container">
        <div class="form_register">
        <h1>Editar Pedido</h1>
        <hr>
        <div class="alert"><?php echo isset($alert) ?$alert: ''; ?></div>
        <form action="includeS/editarPedido.php"  method="POST">
            <label for="nombre">Cliente</label>
            <input type="text" name="cliente" id="cliente" placeholder="Id Cliente" value="<?= $user['id_cliente'] ?>">
            <label for="nombre">Dirección</label>
            <input type="text" name="direccion" id="direccion" placeholder="Direccion" value="<?= $user['Direccion'] ?>">
            <label for="correo">Teléfono</label>
            <input type="text" name="telefono" id="telefono" placeholder="Telefono" value="<?= $user['Telefono'] ?>">
            <label for="correo">Estatus</label>
            <select name="estado_Actual" id="estado_Actual" >
                <option value="Enviado">Enviado</option>
                <option value="Entregado">Entregado</option>
                <option value="Pendiente">Pendiente</option>
            </select>
            <input type="hidden" name="idPedido" value=<?= $id ?>>
            <input type="submit" value="Guardar" class="btn_save" name="Submit">
        </form>
        </div>
	</section>
</body>
</html>

