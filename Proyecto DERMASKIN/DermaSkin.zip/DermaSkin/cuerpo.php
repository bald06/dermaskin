<?php
require_once "config/conexion.php";
include_once "pedido.php"; 
require_once "templates/header.php";
require_once "templates/links.php";
?>
<style>
    #cajaNormal {
    width: 90%;
    border: 3px;
    margin: 60px 70px;
    }
</style>

<div id="cajaNormal">
<?php if($mensaje!=""){ ?>
    <div class="alert alert-success" >
       <?php echo $mensaje; ?> 
        <a href="mostrar.php" class="badge badage-">Ver Carrito</a>
    </div><br><br>
<?php } ?>
        <div class="row">
            <?php
                $query = mysqli_query($con,"SELECT * FROM producto WHERE id_categoria = 3");
                //validacion
                if ($query) {
                    while ($data = mysqli_fetch_array($query)) { 
                        
            ?>
            <div class="col-3">
                <div class="card">
                    <img 
                        class="card-img-top" 
                        src="assets/img/<?php echo $data['Imagen_Producto'];?>" 
                        alt="<?php echo $data['Imagen_Producto'];?>"  
                        title="<?php echo $data['Nombre_Producto'];?>"
                        data-toggle="popover"
                        data-trigger="hover"
                        data-content="<?php echo $data['Descripcion_Producto'];?>"
                        height="317px"
                    >

                <div class="card-body" >
                        <span><?php echo $data['Nombre_Producto'];?></span>
                        <h5 class="card-title">$<?php echo $data['Precio'];?></h5>
                    <form method="post" action="">
                        <input type="hidden" name="id" id="id" value="<?php echo ($data['id_producto']);?>">
                        <input type="hidden" name="nombre" id="nombre" value="<?php echo ($data['Nombre_Producto']);?>">
                        <input type="hidden" name="precio" id="precio" value="<?php echo ($data['Precio']);?>">
                        <input type="hidden" name="cantidad" id="cantidad" value="<?php echo 1;?>">
                    <!--inicio boton modal-->
                    <button class="btn btn-primary btnProducto"
                    value="<?php ($data['id_producto']);?>" 
                            data-toggle="modal"
                            data-target="#modal1"
                            idProducto=<?= $data['id_producto'] ?> 
                            type="button">Ver detalles
                    </button> <!--cierre boton modal-->
                    <button class="btn btn-primary" 
                            name="btnAccion" 
                            value="Agregar" 
                            type="submit">Agregar al carrito
                        </button>
                    </form>
                    </form>
                  </div>
                  </div>
                </div>   
                  <?php 
                   }
                  } ?>
            </div>
                        <!--inicio modal-->
                        <div class="modal fade" id="modal1">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content" id="productoRes">
                                
                                </div>
                            </div>
                        </div> 
                </div>     
        <br>
<?php 
require_once "templates/footer.php";
?>
