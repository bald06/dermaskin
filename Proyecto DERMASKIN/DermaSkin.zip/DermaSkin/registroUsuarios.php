 		
<?php 
require_once "config/conexion.php";
require_once "templates/header.php";
require_once "templates/links.php";
?>
 
    <?php 
    
    $message= '';
    if (!empty($_POST['name']) && !empty($_POST['lastname']) &&!empty($_POST['email']) && !empty($_POST['password'])) {
        $nombre = $_POST['name'];
        $apellidos = $_POST['lastname'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "INSERT INTO cliente
        (Nombre_Cliente,Apellidos_Cliente,Email,Password,created_at,updated_at,idrol)
        VALUES ('$nombre','$apellidos','$email','$password',CURDATE(),CURDATE(),2)";
            $stmt=$con->prepare($sql);
            
        if ($stmt->execute()) {
            $message = 'Usuario creado correctamente';
        }else{
            $message = 'Lo sentimos, algo salió mal';
        }
    }
    ?>
   
   <br><br>
   <div class="container">
    <div class="row p-5">
        <div class="col-lg-6">
        <img src="assets/img/registro.jpg" style="max-width: 390px;  border-radius: 20px;">
        </div>
        <div class="col-xs-12 col-sm-10 col-md-6 col-lg-6 login">
            <center>
                <h2>Registro</h2>
            </center>
            <br>
           <?php 
            if (!empty($message)):
           ?>
           <p><?= $message?></p>
            <?php endif;?>

            <form action="registroUsuarios.php" class="form-group text-center" style="margin: 0 auto;" method="POST">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Nombre" name="name" id="name">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Apellidos" name="lastname" id="lastname">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Email" name="email" id="email">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Contraseña" name="password" id=="password">
                </div><br>
                <button type="submit" class="btn btn-block" style="background:#21d192;color:#fff;">Registrarme</button>
            </form>
        </div>

    </div>
</div><br>


   <?php require_once "templates/footer.php";?>