<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drrma Skin | Artículos Dermatológicos</title>
    
    <?php require_once "../templates/links.php";?>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
&nbsp;&nbsp;&nbsp;
  <link rel="shortcut icon" type="image/png" href="assets/img/logo.png">
  <a class="navbar-brand" href="#">
    <img id="logo" src="assets/img/logo.png" style="max-width: 70px; max-height:70px;" >
  </a>
  <a class="navbar-brand" href="../index.php">DermaSkin</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="../index.php">Inicio <span class="sr-only">(current)</span></a>
      </li>
    </ul>

    <form class="form-inline my-2 my-lg-0" id="form">
    <ul class="navbar-nav mr-auto">
    <li class="nav-item">
        <a class="nav-link" href="../registro.php" >Iniciar Sesión</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../registroUsuarios.php" >Registrarse </a>
      </li>
      </li>
    </ul>&nbsp;&nbsp;
    <li class="nav-item" style="list-style:none;">
    <style type="text/css" media="screen">
        A:link {text-decoration: none }
        A:visited {color: black;  font-family: arial; text-decoration: none }
    </style>
  
    </li> 
      <a href="mostrar.php"><img  src="../assets/img/carrito.png" style=" max-width: 30px; max-height:30px; " >(<?php
                    echo (empty($_SESSION['CARRITO']))?0:count($_SESSION['CARRITO']);
                ?>)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<th></a>
    </li>
    </li>
    </form>
  </div>
</nav>

  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  
</head>

<body>

 
  <div class="container-fluid fh5co-two-img">
    <div class="row">
      <div class="col-sm-6 pr-0 pl-0">
        <div class="card"> <img class="card-img" src="assets/img/m1.jpg" alt="">
          <div class="card-img-overlay"> </div>
        </div>
      </div>
      <div class="col-sm-6 pr-0 pl-0">
        <div class="card"> <img class="card-img" src="assets/img/h1.png" alt="">
          <div class="card-img-overlay"> </div>
        </div>
      </div>
    </div>
  </div>

  <div class="container-fluid fh5co-recent-work">
    <div class="container contact-pop">
      <div class="row">
        <div class="col-md-6  pr-0">
          <div class="card"> <img class="card-img w-100" src="assets/img/doctor.jpg" alt="">
            <div class="card-img-overlay"> </div>
          </div>
        </div>
        <div class="col-md-6 pl-0" id="about">
          <div class="content">
            <h3>Dr. Juan Manuel Estrada</h3>
            <h4>Especialista en Dermatología</h4>
            <hr />
            <p align="justify">Brindamos atención integral a las personas que buscan respuestas sobre afecciones y enfermedades de la piel, las membranas mucosas, el cabello y las uñas. Especialista con experiencia en genética, inmunología, melanoma, enfermedades orales, patología, pediatría, farmacología, salud pública y cirugía. También realizamos cirugía micrográfica de Mohs, cirugía láser, cirugía estética y otros procedimientos quirúrgicos dermatológicos por más de 10 años.</p>
            <p align="justify">En Derma Skin diagnosticamos y tratamos cientos de afecciones, incluidas muchas que son raras o complejas lo más importante para Derma Skin es tu salud.</p>
            <a href="../contacto.php" class="btn">CONTACTANOS</a> </div>
          </div>
        </div>
      </div>
      <div class="container recent" id="activity">
        <div class="row">
          <h2>NUEVOS PRODUCTOS</h2>
          <div class="owl-carousel owl-carousel2 owl-theme">
            <div>
              <div class="card"> <img class="card-img" src="../assets/img/p1.png" alt="">
                <div class="card-img-overlay"> <a href="#"><img src="assets/img/heart.png" class="heart" alt="heart icon"></a>
                  <div class="bottom-text">
                    <h5 class="card-title">Perfect Main Cells</h5>
                    <p class="card-text">Gel Contorno Ocular</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div class="card"> <img class="card-img" src="../assets/img/m2.webp" alt="">
                <div class="card-img-overlay"> <a href="#"><img src="assets/img/heart.png" class="heart" alt="heart icon"></a>
                  <div class="bottom-text">
                    <h5 class="card-title">Desmaquillante</h5>
                    <p class="card-text">Piel Sensible</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div class="card"> <img class="card-img" src="../assets/img/h3.jpg" alt="">
                <div class="card-img-overlay"> <a href="#"><img src="assets/img/heart.png" class="heart" alt="heart icon"></a>
                  <div class="bottom-text">
                    <h5 class="card-title">Hidraloe</h5>
                    <p class="card-text">Piel Mixta</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div class="card"> <img class="card-img" src="../assets/img/p5.webp" alt="">
                <div class="card-img-overlay"> <a href="#"><img src="assets/img/heart.png" class="heart" alt="heart icon"></a>
                  <div class="bottom-text">
                    <h5 class="card-title">Aqualia Thermal</h5>
                    <p class="card-text">Bálsamo</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="container-fluid fh5co-recent-work activity">
    <div class="container recent">
      <div class="row">
        <h2>Nuestros Servicios</h2>
        <div class="owl-carousel owl-carousel3 owl-theme">
          <div>
            <div class="card"> <img class="card-img" src="assets/img/servicio1.jpg" alt="">
              <div class="card-img-overlay">
                <div class="bottom-text">
                  <h5 class="card-title">EXFOLIACIONES QUÍMICAS  &nbsp; Tratamientos específicos para revelar una piel más suave y visiblemente más sana</h5>
                  <a href="#"><img src="assets/img/double-right.svg" alt=""></a> 
                </div>
              </div>
            </div>
          </div>
          <div>
            <div class="card"> <img class="card-img" src="assets/img/servicio2.jpg"  alt="">
              <div class="card-img-overlay">
                <div class="bottom-text">
                  <h5 class="card-title">LÁSER NO ABLATIVO &nbsp; &nbsp; Tratamiento de recuperación de la piel para mejorar el envejecimiento y las marcas de imperfecciones</h5>
                  <a href="#"><img src="assets/img/double-right.svg" alt=""></a> 
                </div>
              </div>
            </div>
          </div>
          <div>
            <div class="card"> <img class="card-img" src="assets/img/servicio3.jpg" alt="">
              <div class="card-img-overlay">
                <div class="bottom-text">
                  <h5 class="card-title">RODILLO CON MICROAGUJAS &nbsp; &nbsp; Trataniento mínimamente invasivo para mejorar la edad de la piel y las marcas</h5>
                  <a href="#"><img src="assets/img/double-right.svg" alt=""></a> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid fh5co-about-me" id="testimonial">
    <div id="my-carousel" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="card"> <img class="card-img d-block w-100" src="assets/img/about-me-img.jpg" alt="">
          <div class="card-img-overlay">
            <h2>¡Pacientes Satisfechos!</h2>
          </div>
        </div>
        <div class="carousel-item">
          <div class="carousel-caption d-md-block"> <img src="assets/img/quote-icon.png" alt="">
          <p>Estoy muy satisfecho mi tratamiento fue muy bueno y efectivo, las personas que trabajan en Derma Skin son muy profecionales y gracias a ellos mi tratamiento fue rápido y eficaz.</p>
          </div>
        </div>
        <div class="carousel-item active">
          <div class="carousel-caption d-md-block"> <img src="assets/img/quote-icon.png" alt="">
          <p>Mi tratamiento para rejuvenecer la piel ha funcionado de maravilla, llegué a Derma Skin por recomendación de una amiga y es lo mejor que han hecho por mi, estoy muy agradecida. </p>
          </div>
        </div>
        <div class="carousel-item">
          <div class="carousel-caption d-md-block"> <img src="assets/img/quote-icon.png" alt="">
          <p>Gracias a Derma Skin mi acné ha desaparecido y estoy muy feliz, lo recomiendo completamente.</p>
          </div>
        </div>
      </div>
      <ol class="carousel-indicators">
        <li data-target="#my-carousel" data-slide-to="0" > <img src="assets/img/about-me-img1.png" alt=""> <span>Cristhian Romero</span> </li>
        <li class="active" data-target="#my-carousel" data-slide-to="1" aria-current="location"> <img src="assets/img/about-me-img2.png" alt=""> <span>Gabriell Esqueda</span> </li>
        <li data-target="#my-carousel" data-slide-to="2"> <img src="assets/img/about-me-img3.png" alt=""> <span>Carolina Morales</span> </li>
      </ol>
    </div>
  </div>
  
      <h2 class="text-center d-block">NUESTRAS REDES SOCIALES</h2>
      <div class="row social-links">
        <ul class="nav mx-auto">
          <li class="nav-item"> <a class="nav-link" href="https://www.facebook.com/juanmanuel.dermaskin.9"><img src="assets/img/facebook.png" alt=""></a> </li>
          <li class="nav-item"> <a class="nav-link" href="https://twitter.com/JuanMan36242962"><img src="assets/img/twitter.png" alt=""></a> </li>
        </ul>
      </div>
    </div>
  </div>

  <!-- jQuery first, then Popper.js, then Bootstrap JS --> 
  <script src="assets/js/jquery-3.3.1.slim.min.js"></script> 
  <script src="assets/js/popper.min.js" ></script> 
  <script src="assets/js/bootstrap.min.js"></script> 
  <script src="assets/js/owl.carousel.min.js"></script> 
  <script src="assets/js/main.js"></script>

</body>
</html>