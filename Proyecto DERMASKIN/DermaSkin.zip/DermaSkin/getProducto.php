<?php 
require_once 'config/conexion.php';

if(isset($_GET)){
    
    $id = $_GET['id'];
    
    $sql = "SELECT * FROM  producto where id_producto=$id";
    $query = mysqli_query($con,$sql);


    $producto = mysqli_fetch_assoc($query);

    echo json_encode($producto);
    die();

}

?>