document.addEventListener('DOMContentLoaded', () =>  {
    const btnProducto = document.querySelectorAll('.btnProducto');
    const divRespuesta = document.getElementById('productoRes');
    btnProducto.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const id = e.target.getAttribute('idProducto');

            fetch(`./getProducto.php?id=${id}`)
            .then(res => res.json())
            .then(data => {
                let producto = data;

                let template = `
                <div class="modal-header">
                
                    <h5 class="modal-title"><font color="Darkturquoise " face="arial,verdana" >${producto.Nombre_Producto}</font></h5>
                </div>
                <div class="modal-body">
                <div class="row" style="margin: auto; height: 100%"> 
                    <div class="col-6">
                        <div class="card">
                            <img 
                                class="card-img-top" 
                                src="assets/img/${producto.Imagen_Producto}" 
                                alt="${producto.Imagen_Producto}"  
                                title="${producto.Nombre_Producto}"
                                height="317px"
                            >
                            <div class="card-body" >
                            
                                <h5 class="card-title">${producto.Nombre_Producto}</h5>
                            </div>
                        </div>

                    </div>
                        <div class="col-6">
                        <h4 ><font color="Teal" face="arial,verdana">Marca: </font></h4>
                            <h5 class="card-title">${producto.Marca}</h5>
                            <br>
                            <h4 ><font color="Teal" face="arial,verdana">Precio: </font></h4>
                            <h5 class="card-title">$${producto.Precio}</h5>
                            <br>
                            <h4 ><font color="Teal" face="arial,verdana">Descripción: </font></h4>
                            <h5 class="card-title" align="justify">${producto.Descripcion_Producto}</h5>
                            
                         </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                    
                </div>
                `;

                divRespuesta.innerHTML = template;
                //abajo de cerrar<button type="button" class=" btn btn-primary" productoID=${producto.id_producto}>Comprar</button>
                
            });
        })
    })
})