
<?php error_reporting(0);?>
<?php require_once "templates/header.php";?>
<?php require_once "templates/links.php";?>

   <!--<php require_once "assets/js/script.js";?>
   <php require_once "assets/css/estilo.css";?>-->
   <div class="row justify-content-center">
    <div class="col-md-12">
        <br><br>
    </div>
    <div class="col-md-5">
        <form action="contacto.php" method="POST" autocomplete="off">
            <label for="nombre">Nombre:</label>
            <input type="text" class="form-control" name="nombre"  pattern="[^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1])[a-zA-ZÀ-ÿ\u00f1\u00d1]+$]+">
            <label for="apellidos">Apellidos:</label>
            <input type="text" class="form-control" name="apellidos"  pattern="[^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1])[a-zA-ZÀ-ÿ\u00f1\u00d1]+$]+">
            <label for="email">Email:</label>
            <input type="email" class="form-control" name="email">
            <label for="mensaje">Mensaje:</label>
            <textarea name="mensaje" class="form-control">

            </textarea>
            <br>
            <br>
            <input type="submit" value="Enviar" class="btn btn-success">
        </form>
    </div>
    <div class="col-md-5">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d659.8154179447025!2d-103.36281054515999!3d20.690738432976506!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8428ae21abe3f50b%3A0x65d3b871b4c7b434!2sDermat%C3%B3logo%20Dr.Juan%20Manuel%20Estrada!5e0!3m2!1ses!2smx!4v1593040657074!5m2!1ses!2smx" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>
</div><br><br><br>
<?php


// Aquí se deberían validar los datos ingresados por el usuario
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$email= $_POST['email'];
$messaje = $_POST['mensaje'];

$header = 'From: ' .$email."\r\n";
$header .= "X-Mailer: PHP/" . phpversion()."\r\n";
$header .= "Mine-Version: 1.0\r\n";
$header .= "Content-Type: text/plain";

$message = "Detalles del formulario de contacto:\n\n";
$message .= "Nombre: " . $_POST['nombre'] . "\n";
$message .= "Apellido: " . $_POST['apellidos'] . "\n";
$message .= "E-mail: " . $_POST['email'] . "\n";
$message .= "Comentarios: " . $_POST['mensaje'] . "\n\n";

$para = 'taniajimarq.utj@gmail.com';
$asunto = 'Contacto desde el sitio web';

mail($para, $asunto, utf8_decode($message), $header);

?>
   <?php require_once "templates/footer.php";?>





