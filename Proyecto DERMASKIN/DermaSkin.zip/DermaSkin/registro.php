   <?php require_once "templates/header.php";?>
   <?php require_once "templates/links.php";?>
   <?php 
     if(isset($_SESSION['logindat']))
     {
     	header('location:pagina.php');
     }
     else
     {
   ?>
   <!--Vista del formulario de inicio de sesión-->
<div class="container"><br><br><br><br>
    <div class="row p-5">
        <div class="col-lg-6">
            <img src="assets/img/inicio.jpg" style="max-width: 350px;  border-radius: 20px;">
        </div>
        <div class="col-xs-12 col-sm-10 col-md-6 col-lg-6 login">
            <center>
                <h1>Inicia Sesión</h1>
            </center>
            <br>
           
            <form action="pagina.php" class="form-group text-center" method="POST" style="margin: 0 auto;">
                <input type="email" class="form-control" placeholder="Email" name="email" required>
                <br>
                <input type="password" class="form-control" placeholder="Contraseña" name="password" required>
                <br>
                <input type="submit" name="envio" value="Entrar" class="btn btn-block" style="background: #21d192; color:#fff;">
                <br>
            </form>
            </div>
    </div>
</div><br><br><br><br>
   <?php } require_once "templates/footer.php";?>
