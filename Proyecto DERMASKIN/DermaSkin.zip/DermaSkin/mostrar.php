<?php
//require_once 'config/conexion.php';
require_once 'pedido.php';

?>
<?php require_once "templates/header.php";?>
<?php require_once "templates/links.php";?>
   <div class="sociales">
   <ul>
    <li><a href="https://www.facebook.com/tania.jimarq.3/" target="_blank" class="fab fa-facebook-f"style="color: #fff"></a></li>
    <li><a href="https://m.me/bryan.diaz.90290" target="_blank" class="fab fa-facebook-messenger" style="color: #fff"></a></li>
    <li><a href="https://api.whatsapp.com/send?phone=5213326151405&text=Hola%20Derma%20Skin" target="_blank" class="fab fa-whatsapp" style="color: #fff"></a></li>
    </ul>
   </div>
   <style>
#cajaNormal {
  width: 90%;
  border: 3px;
  margin: 30px 60px;
  
}
</style>
   <div id="cajaNormal">
<h3>Lista de productos</h3>
<?php  if(!empty($_SESSION['CARRITO'])){?>
<table class="table table-light table-hover">
    <tbody>
        <tr>
            <th width="40%">Nombre  </th>
            <th width="15%" class="text-center">Cantidad </th>
            <th width="20%" class="text-center">Precio </th>
            <th width="20%" class="text-center">Total </th>
            <th width="5%" class="text-center">--</th>
        </tr>
        <?php $total=0;?>
        <?php
            foreach ($_SESSION['CARRITO'] as $indice => $data) {
        ?>
        <tr>
            <td width="40%"><?php echo $data['Nombre']?></td>
            <td width="15%" class="text-center"><?php echo $data['Cantidad']?></td>
            <td width="20%" class="text-center"><?php echo $data['Precio']?></td>
            <td width="20%" class="text-center"><?php echo number_format($data['Precio']*$data['Cantidad'],2);?></td>
            <td width="5%">
            <form method="POST" action="">
                 <input type="hidden" name="id" id="id" value="<?php echo $data['Id'];?>">
                <button class="btn btn-danger" type="submit" name="btnAccion" value="Eliminar">Eliminar</button>
            </form></td>
        </tr>
        <?php $total=$total+($data['Precio']*$data['Cantidad']);?>
            <?php } ?>
        <tr>
            <td colspan="3" align="right"><h3>Total</h3></td>
            <td align="right"><h3>$<?php echo number_format($total,2); ?></h3></td>
        </tr>
        <tr>
        <td colspan="5" align="right">
          <?php if(isset($_SESSION['logindat'])):  ?>
            <a href="datos.php" class="btn btn-outline-success btn-lg active" role="button" aria-pressed="true">Efectuar Compra >></a>

          <?php else: ?>
            <h4>Debes iniciar sesión para continuar</h4>

          <?php  endif; ?>
        </tr>
    <tr>  
        <!--td>
         <button type="button" class="btn btn-outline-warning"><a href="cerrar.php">Vaciar carrito</a></button>
         </td-->
    </tr> 
    </tbody>  
</table>
<?php }else{ ?>
    <div class="alert alert-success">
    No hay productos en el carrito    
    </div>
    <?php } ?>
</body>
</html>
</div>
<br><br><br><br><br><br><br>
<?php require_once "templates/footer.php";?>
