<?php 
require_once 'config/conexion.php';
?>
<?php

if (!empty($_POST['nombre']) && !empty($_POST['apellidos'])  && !empty($_POST['estado']) && !empty($_POST['municipio']) 
        && !empty($_POST['direccion']) && !empty($_POST['codigopostal']) && !empty($_POST['telefono'])) {
        $idCliente = $_SESSION['logindat']['id_cliente'];
        $nombre = $_POST['nombre'];
        $apellidos = $_POST['apellidos'];
        $estado = $_POST['estado'];
        $municipio = $_POST['municipio'];
        $direccion = $_POST['direccion'];
        $codigopostal = $_POST['codigopostal'];
        $telefono = $_POST['telefono'];
        $montoTotal = 0;
        
        
        foreach ($_SESSION['CARRITO'] as $producto) {
            $montoTotal+=($producto['Cantidad']*$producto['Precio']);
            $cantidad = (int)$producto['Cantidad'];
            $id = $producto['Id'];
            $reducirStock = mysqli_query($con,"UPDATE producto SET Stock =(Stock-$cantidad) WHERE id_producto=$id");
        }
        $sql = "INSERT INTO pedido (id_cliente,Estado,Municipio,Direccion,Codigo_Postal,Telefono,created_at,updated_at,Estado_Actual,Monto)
        VALUES ($idCliente,'$estado','$municipio','$direccion','$codigopostal','$telefono',CURTIME(),CURTIME(),'Pendiente',$montoTotal)";
        $query = mysqli_query($con,$sql);
        
        if($query){
            $sql = "SELECT MAX(id_pedido) as ultimo_id from pedido";
            $query = mysqli_query($con,$sql);
            $ultimoId = mysqli_fetch_array($query)['ultimo_id'];
            foreach ($_SESSION['CARRITO'] as $producto) {
                $IdProducto = $producto['Id'];
                $cantidad = $producto['Cantidad'];
                $subtotal = $producto['Cantidad']*$producto['Precio'];
                $sql = "INSERT INTO detalle_pedido (id_pedido,id_producto,cantidad_producto,subtotal) VALUES ($ultimoId, $IdProducto, $cantidad, $subtotal )";

                $query = mysqli_query($con,$sql);
            }

            header('location: compra.php');
        }else{
            echo mysqli_error($con);
            die();
        }   
    }
    ?>
    <?php 
            if (!empty($message)):
           ?>
           <p><?= $message?></p>
            <?php endif;?>