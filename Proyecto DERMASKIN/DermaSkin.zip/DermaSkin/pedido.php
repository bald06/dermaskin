<?php
require_once 'config/conexion.php';
require_once "templates/header.php";
require_once "templates/links.php";

$mensaje="";



    if(isset($_POST['btnAccion'])){
        switch($_POST['btnAccion']){
            case 'Agregar':
                if(is_numeric($_POST['id'])){
                    $Id=($_POST['id']);
                    //$mensaje.="Id: ".$Id."</br>";
                }else{
                    $mensaje.="ID Incorrecto";
                }
                if(is_string($_POST['nombre'])){
                    $Nombre=($_POST['nombre']);
                    $mensaje.="Nombre: ".$Nombre."</br>";
                }else{
                    $mensaje.="Nombre incorrecto";
                break;
                }
                if(is_numeric($_POST['precio'])){
                    $Precio=($_POST['precio']);
                    $mensaje.="Precio: ".$Precio."</br>";
                }else{
                    $mensaje.="Precio incorrecto";
                break;
                }
                if(is_numeric($_POST['cantidad'])){
                    $Cantidad=($_POST['cantidad']);
                    $mensaje.="Cantidad: ".$Cantidad."</br>";
                }else{
                    $mensaje.="Cantidad incorrecta incorrecto";
                break;
                }
            if(!isset($_SESSION['CARRITO'])){
                $producto=array(
                    'Id'=> $Id, 'Nombre'=> $Nombre, 'Precio'=> $Precio, 'Cantidad'=> 1
                );
                $_SESSION['CARRITO'][0]=$producto;
            }else{
                $numProductos=count($_SESSION['CARRITO']);
                $cont = 0;
                foreach($_SESSION['CARRITO'] as $index=>$product){
                    if((int)$product['Id']== $Id) {
                         $_SESSION['CARRITO'][$index]['Cantidad']++;
                         $cont++;
                    }
                }
                if($cont==0){
                    $producto=array(
                        'Id'=> $Id, 'Nombre'=> $Nombre, 'Precio'=> $Precio, 'Cantidad'=> $Cantidad
                    );
                    $_SESSION['CARRITO'][]=$producto;
                }     
            }
            break;
            case "Eliminar":
                if(is_numeric($_POST['id'])){
                    $Id=($_POST['id']);
                   foreach($_SESSION['CARRITO'] as $indice=>$producto){
                        if($producto['Id']==$Id){
                            unset($_SESSION['CARRITO'][$indice]);
                            echo"<script>alert('Elemento borrado')</script>";
                        }
                   }
                }else{
                    $mensaje.="ID Incorrecto";
                }
            break;
            case "Pagar":
                
            break;
        }
    }
?>