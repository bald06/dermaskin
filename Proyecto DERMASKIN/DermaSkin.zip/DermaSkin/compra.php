<?php 
require_once "detallePedido.php";
require_once "templates/header.php";
require_once "templates/links.php";


//Obtener pedidos del usuario 
$idCliente = $_SESSION['logindat']['id_cliente'];
$sql = "SELECT * FROM pedido WHERE id_cliente = $idCliente";
$query = mysqli_query($con,$sql);
?>
 
<style>
#cajaNormal {
  width: 90%;
  border: 3px;
  margin: 30px 60px;  
}
</style>
<div class="alert alert-success">
    <h3 class="text-center">Tu pedido se realizó exitosamente</h3>   
    </div>
   <div id="cajaNormal">
<h3>Mis Pedidos</h3>
<table class="table table-light table-hover">
    <tbody>
        <tr>
            <th width="25%" class="text-center">Acción</th>
            <th width="25%" class="text-center">Total Pagado </th>
            <th width="25%" class="text-center">Fecha del pedido </th>
            <th width="25%" class="text-center">Estatus del pedido </th>
        </tr>
        <?php $total=0;?>
        <!-- Por cada pedido en el arreglo de la bd va a imprimir una fila con los datos -->
        <?php while ($pedido = mysqli_fetch_array($query)): ?>
        <tr>
            <td width="25%" class="text-center"><button type="button" class="btn btn-light"><a href="detalleCompra.php?pedido=<?= $pedido['id_pedido'] ?>">Detalles del pedido</a></button></td>
            <td width="25%" class="text-center"><?= $pedido['Monto']?></td>
            <td width="25%" class="text-center"><?= $pedido['updated_at']?></td>
            <td width="25%" class="text-center"><?= $pedido['Estado_Actual']?></td>
        </tr>
            <?php endwhile; ?>
        
    </tbody>  
</table>
</div>
<br><br><br><br><br><br><br>
<?php require_once "templates/footer.php";?>